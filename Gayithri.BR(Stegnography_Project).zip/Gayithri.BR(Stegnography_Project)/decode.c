#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"
#include "decode.h"

/*---------------------------------------------
 * Function: read_and_validate_decode_args
 * Validate and parse command-line arguments
 *--------------------------------------------*/
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if (argv[2] != NULL && strstr(argv[2], ".bmp"))
    {
        decInfo->d_src_image_fname = argv[2];
    }
    else
    {
        printf("Error: Please provide a valid .bmp stego image\n");
        return e_failure;
    }

    if (argv[3] != NULL)
    {
        strtok(argv[3], "."); // Strip extension for later appending
        decInfo->d_secret_fname = argv[3];
    }
    else
    {
        decInfo->d_secret_fname = malloc(100); // Sufficient space
        strcpy(decInfo->d_secret_fname, "decode");
    }

    return d_success;
}

/*---------------------------------------------
 * Function: open_files_dec
 * Open stego image file for decoding
 *--------------------------------------------*/
Status open_files_dec(DecodeInfo *decInfo)
{
    decInfo->fptr_d_src_image = fopen(decInfo->d_src_image_fname, "rb");
    if (decInfo->fptr_d_src_image == NULL)
    {
        printf("Error: Unable to open stego image file\n");
        return d_failure;
    }
    return d_success;
}

/*---------------------------------------------
 * Function: decode_size_from_lsb
 * Decode 32-bit integer from LSBs of 32 bytes
 *--------------------------------------------*/
Status decode_size_from_lsb(char *buffer, int *size)
{
    *size = 0;
    for (int i = 0; i < 32; i++)
        *size = (*size << 1) | (buffer[i] & 1);
    return d_success;
}

/*---------------------------------------------
 * Function: decode_byte_from_lsb
 * Decode one byte from 8 LSBs
 *--------------------------------------------*/
Status decode_byte_from_lsb(char *data, char *image_buffer)
{
    *data = 0;
    for (int i = 0; i < 8; i++)
        *data = (*data << 1) | (image_buffer[i] & 1);
    return d_success;
}

/*---------------------------------------------
 * Function: decode_data_from_image
 * Decode 'size' bytes of data from image
 *--------------------------------------------*/
Status decode_data_from_image(int size, FILE *fptr_d_src_image, char *output_buffer)
{
    char image_buffer[8];
    for (int i = 0; i < size; i++)
    {
        fread(image_buffer, 1, 8, fptr_d_src_image);
        decode_byte_from_lsb(&output_buffer[i], image_buffer);
    }
    output_buffer[size] = '\0';
    return d_success;
}

/*---------------------------------------------
 * Function: decode_magic_string_size
 * Extract the magic string size
 *--------------------------------------------*/
Status decode_magic_string_size(DecodeInfo *decInfo, int *magic_len)
{
    char buffer[32];
    fread(buffer, 1, 32, decInfo->fptr_d_src_image);
    decode_size_from_lsb(buffer, magic_len);
    return d_success;
}

/*---------------------------------------------
 * Function: decode_magic_string
 * Extract magic string itself
 *--------------------------------------------*/
Status decode_magic_string(DecodeInfo *decInfo, int magic_len)
{
    decInfo->magic_data = malloc(magic_len + 1);
    if (!decInfo->magic_data) return d_failure;

    decode_data_from_image(magic_len, decInfo->fptr_d_src_image, decInfo->magic_data);
    decInfo->magic_data[magic_len] = '\0';
    return d_success;
}

/*---------------------------------------------
 * Function: decode_file_extn_size
 * Extract the size of file extension
 *--------------------------------------------*/
Status decode_file_extn_size(FILE *fptr_d_src_image, int *extn_size)
{
    char buffer[32];
    fread(buffer, 1, 32, fptr_d_src_image);
    decode_size_from_lsb(buffer, extn_size);
    return d_success;
}

/*---------------------------------------------
 * Function: decode_secret_file_extn
 * Extract actual extension string
 *--------------------------------------------*/
Status decode_secret_file_extn(char *file_ext, DecodeInfo *decInfo, int extn_size)
{
    decode_data_from_image(extn_size, decInfo->fptr_d_src_image, file_ext);
    file_ext[extn_size] = '\0';
    return d_success;
}

/*---------------------------------------------
 * Function: decode_secret_file_size
 * Extract size of secret file content
 *--------------------------------------------*/
Status decode_secret_file_size(FILE *fptr_d_src_image, int *file_size)
{
    char buffer[32];
    fread(buffer, 1, 32, fptr_d_src_image);
    decode_size_from_lsb(buffer, file_size);
    return d_success;
}

/*---------------------------------------------
 * Function: decode_secret_file_data
 * Decode and save the actual secret file
 *--------------------------------------------*/
Status decode_secret_file_data(DecodeInfo *decInfo)
{
    char *secret_data = malloc(decInfo->size_secret_file + 1);
    if (!secret_data) return d_failure;

    decode_data_from_image(decInfo->size_secret_file, decInfo->fptr_d_src_image, secret_data);
    secret_data[decInfo->size_secret_file] = '\0';

    decInfo->fptr_d_secret = fopen(decInfo->d_secret_fname, "w");
    if (!decInfo->fptr_d_secret)
    {
        printf("Error: Could not open output file\n");
        free(secret_data);
        return d_failure;
    }

    fwrite(secret_data, 1, decInfo->size_secret_file, decInfo->fptr_d_secret);
    fclose(decInfo->fptr_d_secret);

    printf("\nDecoded Secret Content:\n%s\n", secret_data);
    printf("Decoded secret saved to: %s\n", decInfo->d_secret_fname);

    free(secret_data);
    return d_success;
}

/*---------------------------------------------
 * Function: do_decoding
 * Main decoding control logic
 *--------------------------------------------*/
Status do_decoding(DecodeInfo *decInfo)
{
    if (open_files_dec(decInfo) != d_success)
        return d_failure;

    printf("File opened successfully.\n");

    fseek(decInfo->fptr_d_src_image, 54, SEEK_SET);

    int magic_len;
    if (decode_magic_string_size(decInfo, &magic_len) != d_success)
        return d_failure;
    printf("Decoded Magic String Length: %d\n", magic_len);

    if (decode_magic_string(decInfo, magic_len) != d_success)
        return d_failure;
    printf("Decoded Magic String: %s\n", decInfo->magic_data);

    int extn_size;
    if (decode_file_extn_size(decInfo->fptr_d_src_image, &extn_size) != d_success)
        return d_failure;
    printf("Decoded File Extension Size: %d\n", extn_size);

    char extn[extn_size + 1];
    if (decode_secret_file_extn(extn, decInfo, extn_size) != d_success)
        return d_failure;
    printf("Decoded File Extension: %s\n", extn);

    if (!strstr(decInfo->d_secret_fname, extn))
    {
        strcat(decInfo->d_secret_fname, extn);
    }

    int file_size;
    if (decode_secret_file_size(decInfo->fptr_d_src_image, &file_size) != d_success)
        return d_failure;
    decInfo->size_secret_file = file_size;
    printf("Decoded Secret File Size: %d\n", file_size);

    if (decode_secret_file_data(decInfo) != d_success)
        return d_failure;

    return d_success;
}
