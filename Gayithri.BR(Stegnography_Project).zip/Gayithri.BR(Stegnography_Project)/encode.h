#ifndef ENCODE_H
#define ENCODE_H

#include "types.h" // Contains user-defined types and status enums

/*---------------------------------------------
 * Definitions
 *--------------------------------------------*/

// Maximum buffer sizes for encoding
#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

/*---------------------------------------------
 * Structure: EncodeInfo
 * Description: Holds all necessary information
 *              for encoding a secret file into
 *              a BMP image.
 *--------------------------------------------*/

typedef struct _EncodeInfo
{
    /* Source Image Info */
    char *src_image_fname;
    FILE *fptr_src_image;
    uint image_capacity;
    uint bits_per_pixel;
    char image_data[MAX_IMAGE_BUF_SIZE];

    /* Secret File Info */
    char *secret_fname;
    FILE *fptr_secret;
    char extn_secret_file[MAX_FILE_SUFFIX];
    char secret_data[MAX_SECRET_BUF_SIZE];
    long size_secret_file;

    /* Stego Image Info */
    char *stego_image_fname;
    FILE *fptr_stego_image;

    /* Magic string (used as a marker) */
    char magic_string[100];

} EncodeInfo;

/*---------------------------------------------
 * Function Prototypes for Encoding Process
 *--------------------------------------------*/

/* Detect operation type from command-line arguments */
OperationType check_operation_type(char *argv[]);

/* Read and validate input arguments for encoding */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo);

/* Perform encoding process */
Status do_encoding(EncodeInfo *encInfo);

/* Open source, secret, and output files */
Status open_files(EncodeInfo *encInfo);

/* Check whether the image has capacity to store the secret */
Status check_capacity(EncodeInfo *encInfo);

/* Get size of BMP image in bytes */
uint get_image_size_for_bmp(FILE *fptr_image);

/* Get size of secret file in bytes */
uint get_file_size(FILE *fptr);

/* Copy the BMP file header (first 54 bytes) */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image);

/* Encode the size of magic string */
Status encode_magic_string_size(char *magic_string, EncodeInfo *encInfo);

/* Encode the actual magic string data */
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo);

/* Encode size of the secret file extension (e.g., ".txt") */
Status encode_secret_file_extn_size(int size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* Encode the secret file extension */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo);

/* Encode size of the secret file in bytes */
Status encode_secret_file_size(int file_size, EncodeInfo *encInfo);

/* Encode the actual secret file data */
Status encode_secret_file_data(EncodeInfo *encInfo);

/* Helper to encode data to image using LSB technique */
Status encode_data_to_image(const char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image);

/* Helper to encode 4-byte (int) size using LSB technique */
Status encode_size_to_lsb(int size, char *buffer);

/* Encode 1 byte of data into 8 bytes of image using LSBs */
Status encode_byte_to_lsb(char data, char *image_buffer);

/* Copy remaining image data after encoding is done */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest);

#endif // ENCODE_H
