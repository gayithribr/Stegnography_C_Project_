#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"

/* Validate the input arguments */
Status read_and_validate_encode_args(char *argv[], EncodeInfo *encInfo)
{
    // Validate source image file
    if (strstr(argv[2], ".bmp") != NULL)
    {
        printf(" .bmp image is present\n");
        encInfo->src_image_fname = argv[2];
    }
    else
    {
        printf("Source image is not a .bmp file\n");
        return e_failure;
    }

    // Validate secret file
    FILE *fp = fopen(argv[3], "r");
    if (fp != NULL)
    {
        printf("Secret file is present\n");
        encInfo->secret_fname = argv[3];
        fclose(fp);
    }
    else
    {
        printf(" Secret file is not present\n");
        return e_failure;
    }

    // Validate output stego image or use default
    if (argv[4] != NULL)
    {
        if (strstr(argv[4], ".bmp") != NULL)
        {
            printf("Output stego .bmp file is present\n");
            encInfo->stego_image_fname = argv[4];
        }
        else
        {
            printf(" Output stego image must be .bmp, it is not a .bmp file\n");
            return e_failure;
        }
    }
    else
    {
        encInfo->stego_image_fname = "stego.bmp";  // default name
        printf("Using default stego output: stego.bmp\n");
    }

    return e_success;
}

/* Perform encoding process step by step */
Status do_encoding(EncodeInfo *encInfo)
{
    // Open all required files
    if (open_files(encInfo) == e_success)
    {
        printf("Files are opened successfully\n");
    }
    else
    {
        printf("Files are not opened successfully\n");
        return e_failure;
    }

    // Get magic string from user
    printf("Enter magic string:");
    scanf("%s", encInfo->magic_string);

    // Check if image has enough capacity
    if (check_capacity(encInfo) == e_success)
    {
        printf("Capacity checked is successfull\n");
    }
    else
    {
        printf("Out of capacity\n");
        return e_failure;
    }

    // Copy BMP header
    if (copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success)
    {
        printf("Header bytes are not copied\n");
        return e_failure;
    }
    printf("Header bytes are copied\n");

    // Encode size of magic string
    if (encode_magic_string_size(encInfo->magic_string, encInfo) != e_success)
    {
        printf("Encoded of magic string size is not successful\n");
        return e_failure;
    }
    printf("Encoded of magic string size is successful\n");

    // Encode magic string itself
    if (encode_magic_string(encInfo->magic_string, encInfo) != e_success)
    {
        printf("Encoding magic string is not successful\n");
        return e_failure;
    }
    printf("Encoding magic string is successful\n");

    // Get and encode extension of secret file
    strcpy(encInfo->extn_secret_file, strstr(encInfo->secret_fname, "."));

    if (encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success)
    {
        printf("Encoding a size of secret file extension is not successful\n");
        return e_failure;
    }
    printf("Encoding a size of secret file extension is successful\n");

    if (encode_secret_file_extn(encInfo->extn_secret_file, encInfo) != e_success)
    {
        printf("Encoding a secret file extension is not successful\n");
        return e_failure;
    }
    printf("Encoding a secret file extension is successful\n");

    // Encode size of secret file
    if (encode_secret_file_size(encInfo->size_secret_file, encInfo) != e_success)
    {
        printf("Encoding a secret file size is not successful\n");
        return e_failure;
    }
    printf("Encoding a secret file size is successful\n");

    // Encode secret file data
    if (encode_secret_file_data(encInfo) != e_success)
    {
        printf("Encoding secret data is not successful\n");
        return e_failure;
    }
    printf("Encoding secret data is successful\n");

    // Copy remaining data
    if (copy_remaining_img_data(encInfo->fptr_src_image, encInfo->fptr_stego_image) != e_success)
    {
        printf("Failed to copy remaining data successfully\n");
        return e_failure;
    }
    printf("Copied remaining data successfully\n");

    // Close all files
    fclose(encInfo->fptr_src_image);
    fclose(encInfo->fptr_secret);
    fclose(encInfo->fptr_stego_image);

    return e_success;
}

/* Open input/output files */
Status open_files(EncodeInfo *encInfo)
{
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "rb");
    if (encInfo->fptr_src_image == NULL)
    {
        printf("Source file is not present\n");
        return e_failure;
    }

    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    if (encInfo->fptr_secret == NULL)
    {
        printf("Secret file is not present\n");
        return e_failure;
    }

    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "wb");
    return e_success;
}

/* Get BMP image size in bytes (width * height * 3) */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    fseek(fptr_image, 18, SEEK_SET);
    fread(&width, 4, 1, fptr_image);
    fread(&height, 4, 1, fptr_image);
    return width * height * 3;
}

/* Get file size in bytes */
uint get_file_size(FILE *fptr)
{
    fseek(fptr, 0, SEEK_END);
    return ftell(fptr);
}

/* Check if source image has capacity to encode all secret data */
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    int total_bits_needed =
        32 + strlen(encInfo->magic_string) * 8 +
        32 + strlen(encInfo->extn_secret_file) * 8 +
        32 + encInfo->size_secret_file * 8;

    if (encInfo->image_capacity > total_bits_needed)
    {
        printf("Sufficient capacity\n");
        return e_success;
    }
    else
    {
        printf("Not enough capacity\n");
        return e_failure;
    }
}

/* Copy BMP header (54 bytes) */
Status copy_bmp_header(FILE *fptr_src_image, FILE *fptr_dest_image)
{
    char buffer[54];
    fseek(fptr_src_image, 0, SEEK_SET);
    fread(buffer, 54, 1, fptr_src_image);
    fwrite(buffer, 54, 1, fptr_dest_image);
    return e_success;
}

/* Encode magic string size (as 32 bits) */
Status encode_magic_string_size(char *magic_string, EncodeInfo *encInfo)
{
    char buffer[32];
    int len = strlen(encInfo->magic_string);
    fread(buffer, 32, 1, encInfo->fptr_src_image);
    encode_size_to_lsb(len, buffer);
    fwrite(buffer, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode the actual magic string */
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    encode_data_to_image(magic_string, strlen(magic_string), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode arbitrary data byte-by-byte into image */
Status encode_data_to_image(const char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char image_buffer[8];
    for (int i = 0; i < size; i++)
    {
        fread(image_buffer, 8, 1, fptr_src_image);
        encode_byte_to_lsb(data[i], image_buffer);
        fwrite(image_buffer, 8, 1, fptr_stego_image);
    }
    return e_success;
}

/* Encode a byte into LSB of 8 image bytes */
Status encode_byte_to_lsb(char data, char *image_buffer)
{
    unsigned int mask = 0x80;
    for (int i = 0; i < 8; i++)
    {
        image_buffer[i] = (image_buffer[i] & 0xFE) | ((data & mask) >> (7 - i));
        mask = mask >> 1;
    }
    return e_success;
}

/* Encode secret file extension size (32 bits) */
Status encode_secret_file_extn_size(int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char buffer[32];
    fread(buffer, 32, 1, fptr_src_image);
    encode_size_to_lsb(size, buffer);
    fwrite(buffer, 32, 1, fptr_stego_image);
    return e_success;
}

/* Convert integer to 32 LSB bits in buffer */
Status encode_size_to_lsb(int size, char *buffer)
{
    unsigned int mask = 1 << 31;
    for (int i = 0; i < 32; i++)
    {
        buffer[i] = (buffer[i] & 0xFE) | ((size & mask) >> (31 - i));
        mask = mask >> 1;
    }
    return e_success;
}

/* Encode secret file extension data */
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image(file_extn, strlen(file_extn), encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode size of secret file (32 bits) */
Status encode_secret_file_size(int size, EncodeInfo *encInfo)
{
    char buffer[32];
    fread(buffer, 32, 1, encInfo->fptr_src_image);
    encode_size_to_lsb(size, buffer);
    fwrite(buffer, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode secret file contents into image */
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    fseek(encInfo->fptr_secret, 0, SEEK_SET);
    char str[encInfo->size_secret_file];
    fread(str, encInfo->size_secret_file, 1, encInfo->fptr_secret);
    encode_data_to_image(str, encInfo->size_secret_file, encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

/* Copy the rest of the image after encoding */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch;
    while ((fread(&ch, 1, 1, fptr_src)) > 0)
    {
        fwrite(&ch, 1, 1, fptr_dest);
    }
    return e_success;
}
