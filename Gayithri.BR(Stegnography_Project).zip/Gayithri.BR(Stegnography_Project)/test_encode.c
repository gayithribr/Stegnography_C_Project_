/*
Name        : Gayithri B R
Batch ID    : 25005A_007
Date        : 08/07/2025
Project     : Steganography – Hiding Secret File in a BMP Image

Description :
-------------
This project implements steganography, which hides a secret file inside a BMP image without affecting the visible image quality. The secret file can be a .txt, .csv, or any other type, and is embedded using Least Significant Bit (LSB) encoding. During decoding, the embedded data is extracted back from the stego image.

Operations:
------------
1. Encoding  : ./a.out -e <source_image.bmp> <secret_file> [output_image.bmp]
   - Hides the given secret file inside the BMP image.
   - Generates a stego image with hidden data.

2. Decoding  : ./a.out -d <stego_image.bmp> [output_file]
   - Extracts the secret file from the stego image.
   - Creates the secret output file with original data.

Sample Input / Output:
----------------------
Input:  ./a.out -e beautiful.bmp secret.csv stego.bmp
Output: 
        
        You have chosen Encoding
        .bmp image is present
        Secret file is present
        Using default stego output: stego.bmp
        Read and validate is successful
        =========== Encoding Flow Started ===========
        Files are opened successfully
        Enter magic string:BR
        Sufficient capacity
        Capacity checked is successfull
        Header bytes are copied
        Encoded of magic string size is successful
        Encoding magic string is successful
        Encoding a size of secret file extension is successful
        Encoding a secret file extension is successful
        Encoding a secret file size is successful
        Encoding secret data is successful
        Copied remaining data successfully
        Encoding successful

Input:  ./a.out -d stego.bmp demo.csv
Output:
        You have chosen Decoding
        Read and validate is successful
        =========== Decoding Flow Started ===========
        File opened successfully.
        Decoded Magic String Length: 2
        Decoded Magic String: BR
        Decoded File Extension Size: 4
        Decoded File Extension: .csv
        Decoded Secret File Size: 32

        Decoded Secret Content:
        My password is Gayithri B R ;)

        Decoded secret saved to: demo.csv
        Decoding successful
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

int main(int argc, char *argv[])
{
    // Show help menu if user passes --help
    if (argc == 2 && strcmp(argv[1], "--help") == 0)
    {
        printf("--------------------------------------------------\n");
        printf("           Steganography Tool - Help Menu         \n");
        printf("--------------------------------------------------\n");
        printf("Usage:\n");
        printf("  ./a.out -e <source_image.bmp> <secret_file> [output_image.bmp]\n");
        printf("    - Perform encoding: hide secret inside BMP image.\n\n");
        printf("  ./a.out -d <stego_image.bmp> [output_file]\n");
        printf("    - Perform decoding: extract secret from stego image.\n\n");
        printf("Examples:\n");
        printf("  Encoding  : ./a.out -e input.bmp secret.txt encoded.bmp\n");
        printf("  Decoding  : ./a.out -d encoded.bmp output.txt\n\n");
        printf("Optional:\n");
        printf("  If output file name is not given, default will be used:\n");
        printf("    - For encoding: stego.bmp\n");
        printf("    - For decoding: decode.txt (or based on extension)\n");
        printf("--------------------------------------------------\n");
        return 0;
    }

    // Ensure minimum number of arguments are passed
    if (argc < 3)
    {
        printf("Error: Insufficient arguments.\n");
        printf("Use: ./a.out --help  for usage instructions.\n");
        return e_failure;
    }

    // Determine operation type: encoding or decoding
    if (check_operation_type(argv) == e_encode)
    {
        printf("You have chosen Encoding\n");

        EncodeInfo encode;

        // Read and validate encoding arguments
        if (read_and_validate_encode_args(argv, &encode) == e_success)
        {
            printf("Read and validate is successful\n");
        }
        else
        {
            printf("Read and validate is not successful\n");
            return e_failure;
        }

        printf("=========== Encoding Flow Started ===========\n");

        // Perform encoding
        if (do_encoding(&encode) == e_success)
        {
            printf("Encoding successful\n");
        }
        else
        {
            printf("Encoding unsuccessful\n");
            return e_failure;
        }

        return e_success;
    }
    else if (check_operation_type(argv) == e_decode)
    {
        printf("You have chosen Decoding\n");

        DecodeInfo decode;

        // Read and validate decoding arguments
        if (read_and_validate_decode_args(argv, &decode) == d_success)
        {
            printf("Read and validate is successful\n");
        }
        else
        {
            printf("Read and validate is not successful\n");
            return d_failure;
        }

        printf("=========== Decoding Flow Started ===========\n");

        // Perform decoding
        if (do_decoding(&decode) == d_success)
        {
            printf("Decoding successful\n");
        }
        else
        {
            printf("Decoding unsuccessful\n");

            // Free filename if dynamically allocated
            if (argc < 4)
            {
                free(decode.d_secret_fname);
            }

            return d_failure;
        }

        // Free if default decode file name was used
        if (argc < 4)
        {
            free(decode.d_secret_fname);
        }

        return d_success;
    }
    else
    {
        printf("Invalid operation.\nUse ./a.out --help for usage instructions.\n");
        return d_failure;
    }

    return 0;
}

// Detects the operation type based on command-line arguments
OperationType check_operation_type(char *argv[])
{
    if (strcmp(argv[1], "-e") == 0)
    {
        
        return e_encode;
    }
    else if (strcmp(argv[1], "-d") == 0)
    {
        
        return e_decode;
    }
    else
    {
        return e_unsupported;
    }
}
